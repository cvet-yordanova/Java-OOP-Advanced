package reflection_ex.c_baracks_wars.contracts;

public interface Unit extends Destroyable, Attacker {
}
