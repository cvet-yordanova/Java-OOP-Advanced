package reflection_ex.c_baracks_wars.contracts;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
