package reflection_ex.c_baracks_wars.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
