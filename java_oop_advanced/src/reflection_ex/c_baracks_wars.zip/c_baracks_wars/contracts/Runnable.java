package reflection_ex.c_baracks_wars.contracts;


import java.io.IOException;

public interface Runnable {
	void run() throws IOException;
}
